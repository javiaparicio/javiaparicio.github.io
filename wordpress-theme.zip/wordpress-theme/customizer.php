<?php
/**
 * Theme Customizer Options
 * 
 * @package JaviAparicioFoto
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add customizer options
 */
function javi_aparicio_customize_register($wp_customize) {
    
    // Add Language Selection Section
    $wp_customize->add_section('javi_aparicio_languages', array(
        'title' => __('Language Selection', 'javi-aparicio-foto'),
        'description' => __('Configure the language selection menu in the sidebar.', 'javi-aparicio-foto'),
        'priority' => 30,
    ));
    
    // Language 1
    $wp_customize->add_setting('language_1_name', array(
        'default' => 'EN',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('language_1_name', array(
        'label' => __('Language 1 Name', 'javi-aparicio-foto'),
        'description' => __('Display name for the first language (e.g., EN, English)', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_languages',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('language_1_url', array(
        'default' => home_url('/'),
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('language_1_url', array(
        'label' => __('Language 1 URL', 'javi-aparicio-foto'),
        'description' => __('URL for the first language', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_languages',
        'type' => 'url',
    ));
    
    // Language 2
    $wp_customize->add_setting('language_2_name', array(
        'default' => 'ES',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('language_2_name', array(
        'label' => __('Language 2 Name', 'javi-aparicio-foto'),
        'description' => __('Display name for the second language (e.g., ES, Español)', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_languages',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('language_2_url', array(
        'default' => home_url('/es/'),
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('language_2_url', array(
        'label' => __('Language 2 URL', 'javi-aparicio-foto'),
        'description' => __('URL for the second language', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_languages',
        'type' => 'url',
    ));
    
    // Language 3
    $wp_customize->add_setting('language_3_name', array(
        'default' => 'DE',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('language_3_name', array(
        'label' => __('Language 3 Name', 'javi-aparicio-foto'),
        'description' => __('Display name for the third language (e.g., DE, Deutsch)', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_languages',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('language_3_url', array(
        'default' => home_url('/de/'),
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('language_3_url', array(
        'label' => __('Language 3 URL', 'javi-aparicio-foto'),
        'description' => __('URL for the third language', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_languages',
        'type' => 'url',
    ));
    
    // Add Social Links Section
    $wp_customize->add_section('javi_aparicio_socials', array(
        'title' => __('Social Links', 'javi-aparicio-foto'),
        'description' => __('Configure the social media links in the sidebar.', 'javi-aparicio-foto'),
        'priority' => 31,
    ));
    
    // Social 1
    $wp_customize->add_setting('social_1_name', array(
        'default' => 'Pixelfed',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('social_1_name', array(
        'label' => __('Social 1 Name', 'javi-aparicio-foto'),
        'description' => __('Display name for the first social link', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('social_1_url', array(
        'default' => 'https://pixelfed.social/javifoto',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('social_1_url', array(
        'label' => __('Social 1 URL', 'javi-aparicio-foto'),
        'description' => __('URL for the first social link', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('social_1_icon', array(
        'default' => 'iconlocal-pixelfed',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('social_1_icon', array(
        'label' => __('Social 1 Icon Class', 'javi-aparicio-foto'),
        'description' => __('CSS class for the first social icon (e.g., iconlocal-pixelfed)', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'text',
    ));
    
    // Social 2
    $wp_customize->add_setting('social_2_name', array(
        'default' => 'Instagram',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('social_2_name', array(
        'label' => __('Social 2 Name', 'javi-aparicio-foto'),
        'description' => __('Display name for the second social link', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('social_2_url', array(
        'default' => 'https://instagram.com/javiapariciofoto',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('social_2_url', array(
        'label' => __('Social 2 URL', 'javi-aparicio-foto'),
        'description' => __('URL for the second social link', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('social_2_icon', array(
        'default' => 'icon-instagram',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('social_2_icon', array(
        'label' => __('Social 2 Icon Class', 'javi-aparicio-foto'),
        'description' => __('CSS class for the second social icon (e.g., icon-instagram)', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'text',
    ));
    
    // Social 3
    $wp_customize->add_setting('social_3_name', array(
        'default' => 'Telegram',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('social_3_name', array(
        'label' => __('Social 3 Name', 'javi-aparicio-foto'),
        'description' => __('Display name for the third social link', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('social_3_url', array(
        'default' => 'https://t.me/javiapariciofoto',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('social_3_url', array(
        'label' => __('Social 3 URL', 'javi-aparicio-foto'),
        'description' => __('URL for the third social link', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('social_3_icon', array(
        'default' => 'icon-telegram',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('social_3_icon', array(
        'label' => __('Social 3 Icon Class', 'javi-aparicio-foto'),
        'description' => __('CSS class for the third social icon (e.g., icon-telegram)', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'text',
    ));
    
    // Social 4
    $wp_customize->add_setting('social_4_name', array(
        'default' => 'Whatsapp',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('social_4_name', array(
        'label' => __('Social 4 Name', 'javi-aparicio-foto'),
        'description' => __('Display name for the fourth social link', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('social_4_url', array(
        'default' => 'https://wa.me/+41772311263',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('social_4_url', array(
        'label' => __('Social 4 URL', 'javi-aparicio-foto'),
        'description' => __('URL for the fourth social link', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('social_4_icon', array(
        'default' => 'icon-whatsapp',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('social_4_icon', array(
        'label' => __('Social 4 Icon Class', 'javi-aparicio-foto'),
        'description' => __('CSS class for the fourth social icon (e.g., icon-whatsapp)', 'javi-aparicio-foto'),
        'section' => 'javi_aparicio_socials',
        'type' => 'text',
    ));
}
add_action('customize_register', 'javi_aparicio_customize_register');

/**
 * Get language options from customizer
 */
function javi_aparicio_get_language_options() {
    $languages = array();
    
    for ($i = 1; $i <= 3; $i++) {
        $name = get_theme_mod("language_{$i}_name", '');
        $url = get_theme_mod("language_{$i}_url", '');
        
        if (!empty($name) && !empty($url)) {
            $languages[] = array(
                'name' => $name,
                'url' => $url,
            );
        }
    }
    
    return $languages;
}

/**
 * Get social options from customizer
 */
function javi_aparicio_get_social_options() {
    $socials = array();
    
    for ($i = 1; $i <= 4; $i++) {
        $name = get_theme_mod("social_{$i}_name", '');
        $url = get_theme_mod("social_{$i}_url", '');
        $icon = get_theme_mod("social_{$i}_icon", '');
        
        if (!empty($name) && !empty($url) && !empty($icon)) {
            $socials[] = array(
                'name' => $name,
                'url' => $url,
                'icon' => $icon,
            );
        }
    }
    
    return $socials;
}
