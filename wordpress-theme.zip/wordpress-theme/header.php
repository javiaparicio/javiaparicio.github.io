<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="container">
    <!-- Hamburger Icon (Visible on Mobile) -->
    <div class="hamburger" id="hamburger">&#9776;</div>

    <!-- Sidebar -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-logo">
            <?php
            $custom_logo_id = get_theme_mod('custom_logo');
            if ($custom_logo_id) {
                echo wp_get_attachment_image($custom_logo_id, 'full', false, array('alt' => get_bloginfo('name')));
            } else {
                echo '<img src="' . get_template_directory_uri() . '/assets/images/javiAparicioFotoLogo.webp" alt="' . get_bloginfo('name') . '">';
            }
            ?>
        </div>
        
        <ul class="menu-list">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => false,
                'items_wrap' => '%3$s',
                'fallback_cb' => 'javi_aparicio_fallback_menu',
            ));
            ?>
        </ul>
        
        <ul class="language_selector">
            <?php
            // Get language options from customizer
            $languages = javi_aparicio_get_language_options();
            
            if (!empty($languages)) {
                foreach ($languages as $language) {
                    echo '<li><a href="' . esc_url($language['url']) . '">' . esc_html($language['name']) . '</a></li>';
                }
            } else {
                // Fallback to default languages
                $default_languages = array('en' => 'EN', 'es' => 'ES', 'de' => 'DE');
                foreach ($default_languages as $lang_code => $lang_name) {
                    $lang_url = home_url('/');
                    if ($lang_code !== 'en') {
                        $lang_url = home_url('/' . $lang_code . '/');
                    }
                    echo '<li><a href="' . esc_url($lang_url) . '">' . esc_html($lang_name) . '</a></li>';
                }
            }
            ?>
        </ul>
        
        <ul class="socials">
            <?php
            // Get social options from customizer
            $social_links = javi_aparicio_get_social_options();
            
            if (!empty($social_links)) {
                foreach ($social_links as $social) {
                    echo '<li class="socials_item">';
                    echo '<a href="' . esc_url($social['url']) . '" target="_blank" class="socials_item_link" title="' . esc_attr($social['name']) . '">';
                    echo '<span class="' . esc_attr($social['icon']) . '" aria-hidden="true"></span>';
                    echo '</a>';
                    echo '</li>';
                }
            } else {
                // Fallback to default social links
                $default_socials = array(
                    array('name' => 'Pixelfed', 'url' => 'https://pixelfed.social/javifoto', 'icon' => 'iconlocal-pixelfed'),
                    array('name' => 'Instagram', 'url' => 'https://instagram.com/javiapariciofoto', 'icon' => 'icon-instagram'),
                    array('name' => 'Telegram', 'url' => 'https://t.me/javiapariciofoto', 'icon' => 'icon-telegram'),
                    array('name' => 'Whatsapp', 'url' => 'https://wa.me/+41772311263', 'icon' => 'icon-whatsapp'),
                );
                
                foreach ($default_socials as $social) {
                    echo '<li class="socials_item">';
                    echo '<a href="' . esc_url($social['url']) . '" target="_blank" class="socials_item_link" title="' . esc_attr($social['name']) . '">';
                    echo '<span class="' . esc_attr($social['icon']) . '" aria-hidden="true"></span>';
                    echo '</a>';
                    echo '</li>';
                }
            }
            ?>
        </ul>
    </nav>

    <!-- Content -->
    <div class="content" id="content">
